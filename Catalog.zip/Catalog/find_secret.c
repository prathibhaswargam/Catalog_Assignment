#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

// Function to decode Y value based on the given base
long long decodeY(const char *value, int base) {
    return strtoll(value, NULL, base);
}

// Function to perform Lagrange Interpolation and find the constant term
double lagrangeInterpolation(int points[][2], long long y[], int k) {
    double constantTerm = 0.0;

    for (int i = 0; i < k; i++) {
        double term = y[i];

        for (int j = 0; j < k; j++) {
            if (i != j) {
                term *= (0.0 - points[j][0]) / (points[i][0] - points[j][0]);
            }
        }

        constantTerm += term;
    }

    return constantTerm;
}

// Function to find the secret from the input file
double findSecret(const char *filePath) {
    FILE *file = fopen(filePath, "r");
    if (!file) {
        perror("Error opening file");
        return -1;
    }

    // Read the input data
    int n, k;
    fscanf(file, "{\"keys\":{\"n\":%d,\"k\":%d},", &n, &k);

    int points[n][2];
    long long y[n];
    char buffer[256], value[256];
    int index = 0;

    while (fscanf(file, "\"%d\":{\"base\":\"%d\",\"value\":\"%[^\"]\"}", &points[index][0], &points[index][1], value) == 3) {
        y[index] = decodeY(value, points[index][1]);
        index++;
        fscanf(file, ","); // Skip commas
    }

    fclose(file);

    // Use Lagrange Interpolation to calculate the constant term
    return lagrangeInterpolation(points, y, k);
}

int main() {
    const char *file1 = "testcase1.json";
    const char *file2 = "testcase2.json";

    // Calculate the secrets for both test cases
    double secret1 = findSecret(file1);
    double secret2 = findSecret(file2);

    // Output the results
    printf("Secret for Test Case 1: %.0f\n", secret1);
    printf("Secret for Test Case 2: %.0f\n", secret2);

    return 0;
}
